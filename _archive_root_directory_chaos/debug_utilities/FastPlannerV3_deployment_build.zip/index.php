<?php
// Ensure we're serving the index.html content without redirecting
$html = file_get_contents('./index.html');
echo $html;
?>
